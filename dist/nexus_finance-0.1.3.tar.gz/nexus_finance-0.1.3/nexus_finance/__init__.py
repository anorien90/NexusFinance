from .app import UserBaseApplication
from .app_routes import setup_routes

