This software uses DEAP (Distributed Evolutionary Algorithms in Python), which is licensed under the LGPL (Lesser General Public License).

